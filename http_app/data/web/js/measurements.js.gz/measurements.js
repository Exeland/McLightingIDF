var measurementsJson = {};

function convertHMS(value) {
    const sec = parseInt(value, 10); // convert value to number if it's string
    let hours = Math.floor(sec / 3600); // get hours
    let minutes = Math.floor((sec - (hours * 3600)) / 60); // get minutes
    let seconds = sec - (hours * 3600) - (minutes * 60); //  get seconds
    // add 0 if value < 10; Example: 2 => 02
    if (hours < 10) { hours = "0" + hours; }
    if (minutes < 10) { minutes = "0" + minutes; }
    if (seconds < 10) { seconds = "0" + seconds; }
    return hours + ':' + minutes + ':' + seconds; // Return is HH : MM : SS
}

function measurements_update() {
    getFile("measurements.json", function (res) {
        measurementsJson = JSON.parse(res);
        draw_mes();
        for (var key in measurementsJson) {
            let s;
            key = esc(key);
            if (key === 'dev_type') {
                s = conv_dev_name(measurementsJson[key]);
            }
            else if (key === 'dev_mode') {
                s = conv_dev_mode(measurementsJson[key]);
            }
            else if ((key === 't_last') || (key === 't_current') || (key === 't_common')) {
                s = convertHMS(measurementsJson[key]);
            }
            else if ((key === 'voltage') || (key === 'freq') || (key === 'num_starts')) {
                s = measurementsJson[key];
            }
            else {
                s = "unknown";
            }
            _(key).innerHTML = s;
        }
    });
}

const param_name = ["dev_mode", "num_starts", "t_last", "t_current", "t_common", "voltage", "freq"];

function draw_mes() {
    let html = "<table>";
    for (var i = 0; i < param_name.length; i++) {
        let pn = param_name[i];
        if (pn != undefined) {
            html += "<tr><td>" + lang(pn) + "</td><td id=\"" + pn + "\"></td></tr>"
        }
    }
    html += "</table>";
    _("mesureList").innerHTML = html;
}

function load() {
    measurements_update();
    setInterval('measurements_update()', 5000);
}